#include<stdio.h>
#include<stdlib.h>
struct node
{
    int info;
    struct node *prev;
    struct node *next;
};
struct node *head=NULL;
struct node *newnode;
struct node *temp;
void createList()
{
    int n;
    printf("enter no of nodes to be created:");
    scanf("%d",&n);  
    if(n!=0)
    {
        //code to create first node
        newnode=(struct node*)malloc(sizeof(struct node));
        head=newnode;
        temp=head;
        int val1;
        printf("enter the first element:");
        scanf("%d",&val1);
        newnode->info=val1;newnode->prev=NULL;
        int i=2;
        while(i<=n)
        {
            newnode=(struct node*)malloc(sizeof(struct node));
            int val;
            printf("enter %d to be inserted:",i);
            scanf("%d",&val);
            newnode->info=val;
            newnode->prev=temp;
            temp->next=newnode;
            temp=temp->next;
            i++;
        }
    }
    printf("linked list created successfully\n");
}
void traversal(){int i=1;
    struct node *temp1;temp1=head;
    while(temp1!=NULL)
    {
        printf("%d eleement is%d\n",i,temp1->info);
        temp1=temp1->next;
        i++;
    }
}

 

int main()
{
    
    while(1)
    {
        printf("enter 1 for push\n");
        printf("enter 2 for exit\n");
        printf("enter 3 for traversing\n");
        int choice;
        printf("Enter your choice\n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
                createList();
                break;
            case 2:
                traversal();
                break;
           
            case 6:
                exit(0);
                break;
        }
    }
}






