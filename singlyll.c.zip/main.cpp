#include<stdio.h>
#include<stdlib.h>
struct node
{
    int info;
    struct node *link;
};
struct node* head=NULL;
struct node *newnode;
struct node *temp;
void createList()
{
    int n;
    printf("enter no of nodes to be created:");
    scanf("%d",&n);  
    if(n!=0)
    {
        //code to create first node
        newnode=(struct node*)malloc(sizeof(struct node));
        head=newnode;
        temp=head;
        int val1;
        printf("enter the first element:");
        scanf("%d",&val1);
        newnode->info=val1;int i=2;
        while(i<=n)
        {
            newnode=(struct node*)malloc(sizeof(struct node));
            int val;
            printf("enter %d to be inserted:",i);
            scanf("%d",&val);
            newnode->info=val;
            temp->link=newnode;
            temp=temp->link;i++;
        }
    }
    printf("linked list created successfully\n");
   
}


 
//Function to traverse or print linked list
void traverse()
{
	struct node*temp1;
	//list is empty
	if(head==NULL)
	{
		printf("list is empty");
	}
	else{
		temp1=head;
		while(temp1!=NULL){
			printf("Data=%d\n",temp1->info);
			temp1=temp1->link;
		}
	}
}
void addfront()
{ 
    int val;
    for(int i=0;i<1;i++)
    {
    newnode=(struct node*)malloc(sizeof(struct node*));
    printf("enter the value to be inserted in first location");
    scanf("%d",&val);
    newnode->info=val;
    newnode->link=head;
    head=newnode;
    }
}
void addlast()
{
    newnode=(struct node*)malloc(sizeof(struct node*)); 
    int val;
    printf("enter the value to be inserted in last location");
    scanf("%d",&val);
    newnode->info=val;
    temp->link=newnode;
    temp=temp->link;
}


int main()
{
    
    while(1)
    {
        printf("enter 1 for push\n");
        printf("enter 2 for exit\n");
        printf("enter 3 for traversing\n");
        int choice;
        printf("Enter your choice\n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
                createList();
                break;
            case 3:
            	traverse();
            	break;
            case 4:
                addfront();
                printf("%d",head->info);
                break;
            case 5:
                addlast();
                printf("%d",temp->info);
                break;
            case 6:
                exit(0);
                break;
        }
    }
}



