#include<stdio.h>
#include<stdlib.h>
struct node
{
    int info;
    struct node *link;
};
struct node* head=NULL;
struct node *newnode;
struct node *temp;
void createList()
{
    int n;
    printf("enter no of nodes to be created:");
    scanf("%d",&n);  
    if(n!=0)
    {
        //code to create first node
        newnode=(struct node*)malloc(sizeof(struct node));
        head=newnode;
        temp=head;
        int val1;
        printf("enter the first element:");
        scanf("%d",&val1);
        newnode->info=val1;int i=2;
        while(i<=n)
        {
            newnode=(struct node*)malloc(sizeof(struct node));
            int val;
            printf("enter %d to be inserted:",i);
            scanf("%d",&val);
            newnode->info=val;
            temp->link=newnode;
            temp=temp->link;i++;
        }
    }
    printf("linked list created successfully\n");
}


 
//Function to traverse or print linked list
void traverse()
{
	struct node*temp1;
	//list is empty
	if(head==NULL)
	{
		printf("list is empty");
	}
	else{
		temp1=head;
		while(temp1!=NULL){
			printf("Data=%d\n",temp1->info);
			temp1=temp1->link;
		}
	}
}


void printreverse(struct node*tempb)
{
    
    if(tempb==NULL)
    return;
    printreverse(tempb->link);
    printf("tht%d",tempb->info);
    
}
void permanentreverse()
{
    struct node*curr=head;
    struct node*prev=NULL;
    while(curr!=NULL)
    {
        temp=curr->link;
        curr->link=prev;
        prev=curr;
        curr=temp;
    }
    head=prev;
    
}


int main()
{
    
    while(1)
    {
        printf("enter 1 for push\n");
        printf("enter 2 for temporary_reverse\n");
        printf("enter 3 for permanent_reverse\n");
        printf("enter 4 for display\n");
        int choice;
        printf("Enter your choice\n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
                createList();
                break;
            case 2:
                printreverse(head);
                break;
            case 3:
                permanentreverse();
                break;
            case 4:
            	traverse();
            	break;
            case 5:
                exit(0);
                break;
        }
    }
}






