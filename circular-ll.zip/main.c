#include<stdio.h>
#include<stdlib.h>
struct node
{
    int info;
    struct node *link;
};
struct node* head=NULL;
struct node *newnode;
struct node *temp;
void createList()
{
    int n;
    printf("enter no of nodes to be created:");
    scanf("%d",&n);  
    if(n!=0)
    {
        //code to create first node
        newnode=(struct node*)malloc(sizeof(struct node));
        head=newnode;
        temp=head;
        int val1;
        printf("enter the first element:");
        scanf("%d",&val1);
        newnode->info=val1;int i=2;
        while(i<=n)
        {
            newnode=(struct node*)malloc(sizeof(struct node));
            int val;
            printf("enter %d to be inserted:",i);
            scanf("%d",&val);
            newnode->info=val;
            temp->link=newnode;
            temp=temp->link;i++;
        }
        temp->link=head;
    }
    printf("linked list created successfully\n");
   
}


 
//Function to traverse or print linked list
void traverse()                         //for traversing in circular ll do while loop is used
{
	struct node*temp1;
	//list is empty
	if(head==NULL)
	{
		printf("list is empty");
	}
	else{
		temp1=head;
		do{
			printf("Data=%d\n",temp1->info);
			temp1=temp1->link;
		}while(temp1!=head);
	}
}

int main()
{
    
    while(1)
    {
        printf("enter 1 for push\n");
        printf("enter 2 for exit\n");
        printf("enter 3 for traversing\n");
        int choice;
        printf("Enter your choice\n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
                createList();
                break;
            case 2:
            	traverse();
            	break;
            case 3:
                exit(0);
                break;
        }
    }
}






